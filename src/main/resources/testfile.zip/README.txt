



*************************************
** Bulksheet Management Guidelines **
*************************************

Agencies can now download complete campaign structures and statistics across multiple clients and providers,
and receive that data in one file that can be used for reporting, or editing with a subsequent bulksheet import.


Preparation
==================================
The process begins with an Acquisio Bulksheet Export. You can select which objects and metrics to include and
then download the file after it is processed. The Acquisio Bulksheet Export file can then be used for report purposes,
or as a template to add, delete or edit campaigns, adgroups, creatives, keywords, placements or negatives (keyword and
placements). Changes to the file are submitted to Acquisio through the Bulksheet Import process.

Depending on the columns selected for the Bulksheet Export, the file may contain settings and parameters such as budgets,
Max CPC bids and statuses, or it may contain statistical metrics such as clicks and impressions. The exported
data can be modified in Excel, or any other application that works with XLSX or CSV comma-delimited text files. Changes
to settings, structures or bids can be uploaded again in minutes to allow campaign modifications on a scale that
has never been previously available.


Modifications You Can Make
==================================
The bulksheet export allows you to export Campaigns, Adgroups, Creatives, Keywords, Placements or Negatives (keyword and
placements), but there are some things you should know in terms of what changes are accepted through the bulksheet import.
Modifications are only applied to structural properties and settings, but not statistical data.
Therefore all statistical columns in the file are ignored during the import process. While we would all like to be
able to change the click counts for our campaigns, this would not be ethical.

The following structural changes will be supported:
�	Campaign (Create, update and delete)
�	Ad Group (Create, update and delete)
�	Text Ad (Create, update and delete)
�	Keyword (Create, update and delete)
�	Placements (Create, update and delete)
�	Negative Keywords (Create, update and delete)
�	Negative Placements (Create, update and delete)

A reserved column named "ACTION" is used in the file to quickly identify where changes have been made. The manager
declares a row as being a CREATE, UPDATE, or DELETE, which tells Acquisio how to handle the data in that row. Any
rows of data where no action is declared will be ignored during the import process.

Another reserved column named "ROW_TYPE" is used to identify the row object. This column must be present when uploading
changes and must have one of the following identifying values: AGENCY, ACCOUNT, CAMPAIGN_GROUP, CAMPAIGN, ADGROUP, CREATIVE,
KEYWORD, PLACEMENT, CAMPAIGN_NEGATIVE_KEYWORD, ADGROUP_NEGATIVE_KEYWORD, CAMPAIGN_NEGATIVE_PLACEMENT or ADGROUP_NEGATIVE_PLACEMENT.


Special Columns
==================================

Blankable/Nullable Fields
-------------------------
These are fields that behave differently by allowing the user to enter no value in its cell.
When imported, the import process will wipe out any previous value assigned at the engine level.

The following fields support no value
	o	Destination URL
	o	Max CPC
	o	End Date

For example, if the bulksheet export file has a Destination URL for a PPC keyword, you can delete that URL in the file and then
re-import the file. The keyword�s destination URL will be removed at the publisher. To prevent this from happening unexpectedly,
the ACTION column would also require the term UPDATE to appear on the row where the URL was deleted.

Date Formatting
----------------
When exporting and importing changes, different date formats can become a source of unexpected errors. When a CSV file is loaded
in Excel, the software actually changes the date format to one that it recognizes. This often occurs when a CSV with dates in an
international format is loaded into Excel with US Local regional settings. The US Local setting does not support the International
format and therefore changes it to the US format. To reduce the risk misinterpreting date formats, the system will export date
columns using the US date format with 4 digits for the year (MM-DD-YYYY). When importing bulk sheets into Acquisio, the system
will recognize where the 4-digit year is placed (beginning or end) and will assume the following two formats only:
	o	YYYY-MM-DD
	o	MM-DD-YYYY

Boolean fields
---------------
Different publishers may display values of Boolean (logical) fields as Yes/No, On/Off, True/False and other similar combinations.
Acquisio has standardized the formatting for Bulksheet Export and Import and the system will always display
TRUE/FALSE (not case sensitive) values for these columns.

Saving Your Changes and Bulk Importing
---------------------------------------
You can edit your file in any spreadsheet editor such as Excel, and have the option to save your file in XLSX or CSV format if you intend
to upload it through the bulksheet import process. The import process accepts both XLSX and CSV file formats. In addition,
you may compressed your file in a ZIP format before it is transferred to Acquisio.

During the import process, the system will perform a series of in-depth validations prior to sending the changes to the publishers.
Doing so may identify certain common errors and the system will email you a smaller file containing only these errors for you
to correct and retry. Changes that passed our validation process will be sent to each publisher immediately. It may also happen
that additional errors, such as editorial rejections, may be flagged by the publisher later. We will collect those errors and
send them to you separately.

CSV Delimitation Support
-------------------------
In English North America, the columns of CSV files are traditionally delimited by comma separators. However some countries use
commas as the decimal separator, so Acquisio also supports generating an export file delimited by semi-colon. During the Bulksheet Export,
you are asked what symbol should designate decimals in your file. We use this information to select the correct column delimiter,
either the comma or the semi-colon, for your CSV file. This provides compatibility with multiple languages. From an import perspective,
the system only needs to read the first row of column headers to know which delimiter has been used in the files you send to Acquisio.

	Examples
	++++++++
	Example of a USA/UK CSV file (where the decimal separator is a period and the column separator is a comma):
	----------------------------------------
	-- Year,Make,Model,Length             --
	-- 1997,Ford,E350,2.34                --
	-- 2000,Mercury,Cougar,2.38           --
	----------------------------------------

	Example of German and Dutch CSV file (where the decimal separator is a comma and the column separator is a semicolon):
	----------------------------------------
	-- Year;Make;Model;Length             --
	-- 1997;Ford;E350;2,34                --
	-- 2000;Mercury;Cougar;2,38           --
	----------------------------------------

	If you open a Bulk Export file and the columns do not divide correctly, there is a good chance you did not select the decimal
	symbol that matches the current regional settings on your computer.


Adding Keywords or Creatives
==================================
In order to add an object such as a Creative or Keyword, simply place the text label "CREATE" in the column "ACTION" for the desired row.
Then fill in the appropriate columns to define the properties for the keyword or text ad. This might include Max CPC, Status,
Destination URL, as well as the campaign and ad group where the new entity should appear.


Creating and Edit Existing Campaign and Ad Group Objects
==================================
You can bulk create or edit multiple rows in the spreadsheet and modify the settings for any entity of a campaign structure. This includes bids,
statuses, start and stop dates, budgets, keyword destination URLs, etc. Any changes made in the file should have the word CREATE or UPDATE inserted
in the ACTION column for each row where changes have been made. When creating a new Campaign or Ad Group, the bulk import process will apply the
publisher's default settings for any setting values not available in the bulk exported file.

Note that Adwords has never permitted editing a text ad, or its destination URL. If you modify a creative in any way and classify it as an UPDATE,
the actual result will be the deletion of the original ad and the creation of a new ad reflecting the changes. This also occurs if you edit
a keyword or its matchtype, although Adwords will permit you to change the Destination URL of a keyword.


Deleting
==================================
In order to delete an object such as a Campaign, Adgroup, Creative or Keyword, simply place the label "DELETE" in the ACTION column for the
desired row.


Creating Facebook Ads
==================================
When creating new FB ads, it is mandatory that an image be included with the upload. Simply place the appropriate image(s) in the ZIP file
along with the XLSX or CSV file containing your changes. An "IMAGE" column is available in the file where you can record the name of the image file
included in the ZIP. If your original Bulk Export file contains Facebook campaigns, the IMAGE column will be used to hold clickable links
to the images used in the existing ads. If you want to change the image for an existing ad, replace the clickable link with the name of
the new image file, add the label UPDATE to the ACTION column and be sure to include the new image file in the ZIP when you upload the
file to Acquisio.

Facebook Targeting Settings
==================================

BROAD_AGE
Possible values are ENABLED and DISABLED (not case sensitive). The default value will be DISABLED

USER_EVENTS
Possible values are TRUE and FALSE (not case sensitive). The default value will be FALSE

CITY
To add a city in the targeting, you need to provide the name of the city and the initials of the province or state, separated by a "," (comma)
    Example: Toronto, ON
             Montreal, QC

Multi-value columns
Columns that contain multiple values must be delimited with a "|" (pipe)